# Digital Rights

Do human rights apply on the internet? We believe so! 

## Under construction

This project is just beginning, for now you can follow the origins of this project [here](https://github.com/alex-esc/digitalrights).

## Get notified on future updates

Use our [RSS feed](https://github.com/digital-rights/rss/releases.atom) to get updates, to get our RSS feed in your email follow [this instructions](https://www.quora.com/What-is-the-best-free-RSS-to-email-service).

## Contact Information

### Email

> [digital-rights-info@protonmail.com](mailto:digital-rights-info@protonmail.com)

### Social media

[Facebook](https://digital-rights.github.io/facebook), [Twitter](https://digital-rights.github.io/twitter) & [YouTube](https://digital-rights.github.io/youtube).

TEST 123
