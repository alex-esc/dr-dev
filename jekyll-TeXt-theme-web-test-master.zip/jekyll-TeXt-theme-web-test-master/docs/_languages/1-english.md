---
title: English
key: lang-en
permalink: /languages/english.html
cover: /docs/assets/images/languages/lang-en.jpg
lang: en
---

English is the default language of TeXt, if you set `lang` in *_config.yml* to the other language but want make the page English, just set `lang: en` in the front matter.

<!--more-->

**front matter:**

    ---
    ...
    lang: en
    ---