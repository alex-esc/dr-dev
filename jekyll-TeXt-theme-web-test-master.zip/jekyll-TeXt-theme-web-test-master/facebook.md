<meta http-equiv="refresh" content="0; URL='https://www.facebook.com/digitalrightsonline'" />


You are being redirected, if that didn't work [click here](https://www.facebook.com/digitalrightsonline)

