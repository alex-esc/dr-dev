# RSS updates for digital-rights.github.io

Here you will find an archive of all news and updates about the github pages site for digital-rights.

## Subscribe to the RSS feed

RSS Link:

> https://github.com/digital-rights/rss/releases.atom

## Download the archive

For offline use, you can download the archive [here](https://github.com/digital-rights/rss/archive/master.zip).
