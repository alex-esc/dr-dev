<meta http-equiv="refresh" content="0; URL='https://www.youtube.com/channel/UC75Oprp2NYpFg0_S_g_lqBQ/featured'" />


You are being redirected, if that didn't work [click here](https://www.youtube.com/channel/UC75Oprp2NYpFg0_S_g_lqBQ/featured)
